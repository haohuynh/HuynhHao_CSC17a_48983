/* 
 * File:   IndexedColumn.h
 * Author: rcc
 *
 * Created on October 6, 2015, 11:20 AM
 */

#ifndef INDEXEDCOLUMN_H
#define	INDEXEDCOLUMN_H

struct IndxCol{
    int size;
    int *array;
    int *indx;
};

#endif	/* INDEXEDCOLUMN_H */

