/* 
 * File:   CopyFileFilter.cpp
 * Author: HaoHuynh
 * 
 * Created on November 18, 2015, 6:29 PM
 */

#include "CopyFileFilter.h"

CopyFileFilter::CopyFileFilter() {
}

CopyFileFilter::CopyFileFilter(const CopyFileFilter& orig) {
}

CopyFileFilter::~CopyFileFilter() {
}

char CopyFileFilter::transform(char ch) {
    return ch;
}

