var searchData=
[
  ['queen',['QUEEN',['../class_abstract_card_table.html#a7891cd08bcc78e9b277aa99c79ed94edae80fc25c6da6c8b9029126dbe4f4cd58',1,'AbstractCardTable']]]
];
