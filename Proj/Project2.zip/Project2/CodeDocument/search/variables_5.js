var searchData=
[
  ['suit',['suit',['../struct_abstract_card_table_1_1_c_a_r_d.html#adcbeeefd0917156ad87c7b2c2fcb2818',1,'AbstractCardTable::CARD']]],
  ['suit_5fmax',['SUIT_MAX',['../class_abstract_card_table.html#a131393405fd575dc20b7aa12cf25980e',1,'AbstractCardTable']]]
];
