var searchData=
[
  ['ace',['ACE',['../class_abstract_card_table.html#a7891cd08bcc78e9b277aa99c79ed94edaa94565c55708c11dbb54557b9dad2b71',1,'AbstractCardTable']]]
];
