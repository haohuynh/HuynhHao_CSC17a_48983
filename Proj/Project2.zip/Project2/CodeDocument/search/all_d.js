var searchData=
[
  ['nine',['NINE',['../class_abstract_card_table.html#a7891cd08bcc78e9b277aa99c79ed94eda65ffc682554fc646f7dc0020015dd7b3',1,'AbstractCardTable']]]
];
