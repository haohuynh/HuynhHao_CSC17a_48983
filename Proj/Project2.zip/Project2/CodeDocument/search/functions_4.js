var searchData=
[
  ['getinstance',['getInstance',['../class_card_table_helper.html#a4f2016184853fc05d6f10b93325a3326',1,'CardTableHelper']]]
];
