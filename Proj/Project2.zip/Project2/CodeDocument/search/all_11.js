var searchData=
[
  ['rank',['rank',['../struct_abstract_card_table_1_1_c_a_r_d.html#acc357658fb11230706b47885e9083d6f',1,'AbstractCardTable::CARD']]],
  ['ranks_5fper_5fsuit',['RANKS_PER_SUIT',['../class_abstract_card_table.html#ae549f46fdfef86219f4b919463219e43',1,'AbstractCardTable']]],
  ['restart',['RESTART',['../class_card_table_helper.html#abe4109f18ccd4d9029e12e3384fe695fa2befb00f698a13af6e87f6f89df2e1e3',1,'CardTableHelper']]]
];
