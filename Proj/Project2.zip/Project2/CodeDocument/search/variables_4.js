var searchData=
[
  ['rank',['rank',['../struct_abstract_card_table_1_1_c_a_r_d.html#acc357658fb11230706b47885e9083d6f',1,'AbstractCardTable::CARD']]],
  ['ranks_5fper_5fsuit',['RANKS_PER_SUIT',['../class_abstract_card_table.html#ae549f46fdfef86219f4b919463219e43',1,'AbstractCardTable']]]
];
