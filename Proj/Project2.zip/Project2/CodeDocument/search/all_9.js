var searchData=
[
  ['jack',['JACK',['../class_abstract_card_table.html#a7891cd08bcc78e9b277aa99c79ed94edaf874e762ac1c92581289327f2731d633',1,'AbstractCardTable']]]
];
