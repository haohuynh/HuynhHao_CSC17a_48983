var searchData=
[
  ['clubs',['CLUBS',['../class_abstract_card_table.html#a30bc50faceed9baf7245266e0b32fff5afbe8e8bd530b95212707ebc134e93a3f',1,'AbstractCardTable']]]
];
