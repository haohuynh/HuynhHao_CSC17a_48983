var searchData=
[
  ['five',['FIVE',['../class_abstract_card_table.html#a7891cd08bcc78e9b277aa99c79ed94eda552bc9fbd2e9f8ecb1baf2fb343c1e57',1,'AbstractCardTable']]],
  ['four',['FOUR',['../class_abstract_card_table.html#a7891cd08bcc78e9b277aa99c79ed94edac52591516adceb9f4027fd910904c6d3',1,'AbstractCardTable']]]
];
