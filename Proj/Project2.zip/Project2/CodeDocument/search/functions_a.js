var searchData=
[
  ['save',['save',['../class_card_table_helper.html#a7f1e28260d0aa46471d1e74a3b82189f',1,'CardTableHelper']]],
  ['setupgamescreen',['setUpGameScreen',['../main_8cpp.html#aec9da33ee491e372347815fd79865a12',1,'main.cpp']]]
];
