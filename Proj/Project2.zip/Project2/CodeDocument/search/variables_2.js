var searchData=
[
  ['id',['id',['../struct_abstract_card_table_1_1_c_a_r_d.html#ae67233945c1f57fef359f671c9561602',1,'AbstractCardTable::CARD']]]
];
