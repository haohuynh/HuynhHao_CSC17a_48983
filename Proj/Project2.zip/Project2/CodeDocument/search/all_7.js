var searchData=
[
  ['hearts',['HEARTS',['../class_abstract_card_table.html#a30bc50faceed9baf7245266e0b32fff5a90341946b9947870c0e8e1365b64b3a1',1,'AbstractCardTable']]]
];
