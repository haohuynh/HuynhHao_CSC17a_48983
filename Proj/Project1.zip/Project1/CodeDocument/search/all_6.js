var searchData=
[
  ['id',['id',['../struct_c_a_r_d.html#aa4e18d70de2f85cb5f0d1c4383a5cc2e',1,'CARD']]]
];
