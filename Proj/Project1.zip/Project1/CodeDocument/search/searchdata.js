var indexSectionsWithContent =
{
  0: "acdefhijklmnpqrstv~",
  1: "cp",
  2: "mp",
  3: "clmpsv~",
  4: "irs",
  5: "c",
  6: "c",
  7: "acdefhjknqst"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator"
};

