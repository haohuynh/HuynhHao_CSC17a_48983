var searchData=
[
  ['suit',['suit',['../struct_c_a_r_d.html#a1bd0550c8b8125ef1eb1418485fde6e2',1,'CARD']]]
];
