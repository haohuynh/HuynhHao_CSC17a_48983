var searchData=
[
  ['rank',['rank',['../struct_c_a_r_d.html#ad5a80d46c9eb98f2b5b70fe381a7b541',1,'CARD']]]
];
